# ijji.four-beat — motif asset record (ijji-owned)

เจ้าของแบรนด์เลือกให้มาร์กชุดนี้เป็น **asset ของ ijji** ไม่ยกขึ้นเป็น asset ชั้น Landometer
ผลที่ตามมาสองข้อ: ใช้ได้ในบริบทของ ijji เท่านั้น (product identity ข้าม product ไม่ได้) และถ้าวันหนึ่ง
ต้องการตัวบอกสถานะของทั้ง Landometer ต้องทำอีกตัวจากรูปทรงของชั้นกลางเอง ไม่ใช่ยืมชุดนี้ไปใช้

ไฟล์นี้คือ record ที่พร้อมให้เจ้าของ identity เซ็น — ช่องที่ยังว่างระบุไว้ท้ายเอกสาร

```yaml
motifAssetRecordVersion: ijji-motif-asset/0.1
motifId: ijji.four-beat
assetFamily: ijji.four-beat.selected-3
revision: 3
revisionDate: 2026-09-04
owner: ijji
identityRole: none            # ไม่ใช่โลโก้ ไม่แทนโลโก้ ไม่แทน identity context ระดับ artifact
mime: image/svg+xml
intrinsicViewBox: "-20 -20 240 240"
clearSpaceUnits: 20
observableFormSourceRef:
  asset: ijji.logo.legacy.full-square.reference.v1
  sha256: cbeb7bc4db8db795fc669ef521fc05442a275ab63cda866513277cdc75b05a86
  derivation: measured_proportions_only   # วัดรัศมีและระยะห่างของหัวกลมสี่หน่วย ไม่ crop ไม่ trace ไม่ auto-vectorize
headProportions:
  radiusRatio: "1 : 1.583 : 2.167 : 3.167"
  radii: [6.69, 10.593, 14.496, 21.186]
  centresX: [30, 64.566, 104.708, 156]
members:
  - id: graph-b
    meaning: ช่วยให้เติบโตไปด้วยกัน
    loopSeconds: 4.4
    minDeliveredPx: 72
  - id: rings-c
    meaning: รอบรู้ รอบย่าน รอบร้านคุณ
    drawOrder: hub_then_inner_to_outer
    loopSeconds: 5
    minDeliveredPx: 40
  - id: rotate-b
    meaning: ไม่ย่อท้อ มุ่งมั่นไปข้างหน้า
    cadence: one_stop_pause_three_stops_forward_only
    loopSeconds: 4
    minDeliveredPx: 24
colorTreatment:
  type: lds_role_ref_only
  allowedRoleRefs: [energy.mint, text.primary]
  values: { mint: "#0AD69C", ink: "#182327" }
  surfacePairingRefs: [transparent_host_surface, surface.card, brand.blue, dark.surface.card, product.ijji.gradient.light]
  rules:
    - มินต์ทึบบน brand.blue · dark · card ที่เข้มพอ
    - เส้นขอบหมึกบนพื้นอ่อนและบน product.ijji.gradient
    - ห้ามสี semantic · source-status · categorical · sequential · diverging · map
    - ห้าม gradient ในตัวมาร์ก
motionTreatment:
  motionEnabled: true
  sanctionedJob: state_feedback_work_in_progress
  bindsTo: real_pending_operation
  stopsOn: [success, failure, cancel, timeout]
  properties: [transform, opacity, stroke-dashoffset]
  speedVariable: --ijji-speed
  reducedMotion: final_state_immediate       # บล็อกท้าย ijji-motion.css
  noJavaScript: final_state_immediate
  cadenceCeiling: one_animated_instance_per_viewport
  decorativeLoopStatus: not_approved         # ขยับตลอดใน header/hero/footer ยังต้องแก้กติกาสองชั้นก่อน
allowedJobRefs:
  - working_indicator_beside_a_status_line
  - section_orientation_after_identity_is_established
  - quiet_transition_or_closure
  - four_step_process_when_four_labelled_steps_exist
prohibitedContexts:
  - แทนโลโก้ · favicon · touch icon · maskable · social preview · LINE profile/cover
  - ในกราฟ แผนที่ legend evidence mark หรือ source-status badge
  - หน้าเตือนภัย กระแสเงินสด ความปลอดภัยอาหาร กฎหมาย escalation
  - สื่อการเติบโต ความมั่นใจ หรือความสำเร็จ โดยไม่มีตัวเลขกำกับ
  - เคลื่อนไหวโดยไม่มีงานหรือสถานะจริงรองรับ
accessibility:
  meaning: decorative_or_redundant
  ariaTreatment: aria-hidden_on_the_mark__role_status_aria-live_on_the_container
  statusCarrier: visible_text_and_elapsed_time
claimCeiling:
  conformanceLevel: authoring_aligned
  fullDesignsystemAdoptionClaim: false
  machinePackageValidationClaim: false
files:
  - path: svg/ijji-graph-b-brand-blue.svg
    bytes: 8287
    sha256: f99e49088f14a97e6ba5c787708a1d1252734638d0f363f0c2f113258f57ee48
  - path: svg/ijji-graph-b-canvas.svg
    bytes: 8317
    sha256: d8424a94bb8023e0a6d0f63b442e8d6255b9e65c2c6452631a6e11993cec2e9a
  - path: svg/ijji-graph-b-dark.svg
    bytes: 8315
    sha256: 92ed292262b34111d21cbd26ae2fbd8231bda37c2160d0f8ada8d19750d81c19
  - path: svg/ijji-graph-b-ground-mist.svg
    bytes: 8671
    sha256: 591d69e5286fed28e4022b6d02aa3cb6d6a8d8a461df91ba24de8907e3f5807a
  - path: svg/ijji-graph-b-transparent-ink.svg
    bytes: 8344
    sha256: 92c6952e506564e4a85ac8f059890329e50662fa50963292c909c1052bac372a
  - path: svg/ijji-graph-b-transparent-mint.svg
    bytes: 8217
    sha256: 5df64c77388dc1e0f6ddf83080578db9f945966eb2c4f0c09187db2a4b54f7f7
  - path: svg/ijji-rings-c-brand-blue.svg
    bytes: 8530
    sha256: 82e0a26220f54fda854b3e4665c3c6bca64c43d19b048e23bea8a5123be7c276
  - path: svg/ijji-rings-c-canvas.svg
    bytes: 8560
    sha256: e631ec90f2a9ea4cc948b47dd1de3803b63f667dfa41ce271c2523161e0be454
  - path: svg/ijji-rings-c-dark.svg
    bytes: 8558
    sha256: 935eca1e5c3506a65698c471f8b808ea830e6d33273897563a1ecbd8ac6f3e70
  - path: svg/ijji-rings-c-ground-mist.svg
    bytes: 8820
    sha256: ac6642e269c2580e400ef035fc78f790276837ffddefaaa86a8315e156cb7eb0
  - path: svg/ijji-rings-c-transparent-ink.svg
    bytes: 8493
    sha256: e138780914ab1afee9a7cfda3f1eb730fa41917b9acdd678a4545009b7597b10
  - path: svg/ijji-rings-c-transparent-mint.svg
    bytes: 8460
    sha256: 10afbfc96f1a7b4a24ff9220560883efe82bba1e17efbc0dc550dc202e89b028
  - path: svg/ijji-rotate-b-brand-blue.svg
    bytes: 8264
    sha256: dfe1661930f000090c71c66d348654998dc3c255ed35ac913638b5e570ffb7e2
  - path: svg/ijji-rotate-b-canvas.svg
    bytes: 8294
    sha256: 2864e6858eb6e499d4b0b52e2675fb491b470b857cd055400ae99d5fabd79732
  - path: svg/ijji-rotate-b-dark.svg
    bytes: 8292
    sha256: d38add31343cba9a0f4d5b3362bc7b3aff64b10d9f2771c190ce6a8e5124d795
  - path: svg/ijji-rotate-b-ground-mist.svg
    bytes: 8650
    sha256: f2add7418e19cbd92f522588d4dd3441334f3728d3f99a4b48e2a1aa3463aa94
  - path: svg/ijji-rotate-b-transparent-ink.svg
    bytes: 8321
    sha256: c5fd50bf5238daeaac753bb7999d5038ca927b8a1ad96ccfd2b337076234fa38
  - path: svg/ijji-rotate-b-transparent-mint.svg
    bytes: 8194
    sha256: 54fb8ee9c2065e54f1e6de8674b1bf488ef96daf93d81b76cdea38f1466a24c9
  - path: ijji-motion.css
    bytes: 3636
    sha256: 195a53a793d0fd693e0d9e6ec941a687ca3fbb55a7af262d85d0905c6ddf2bf4
  - path: ijji-motifs.js
    bytes: 15288
    sha256: 4f341f6bc0c7acd3d6ce44aad6d798e3f03b26c712a29610ae4985cbe11271a4
```

## ช่องที่ยังต้องเติมก่อนใช้จริง

| ช่อง | ใครปิด | หมายเหตุ |
| --- | --- | --- |
| `approval.owner` · `approvedAt` · `expiresAt` | เจ้าของ identity ijji | บันทึกเป็นไฟล์ approval ไม่ใช่ข้อความในแชต |
| `originalityEvidenceRef` · `nonTraceComparisonRef` | ทีมออกแบบ | หลักฐานว่าเป็นงานวาดใหม่ ไม่ได้ trace — วัดสัดส่วนจากโลโก้ถือเป็น derivation ที่ต้องบันทึก |
| `pseudoLogoSubstitutionTestRef` | design QA | ทดสอบว่าไม่มีใครเข้าใจผิดว่ามาร์กคือโลโก้ |
| `contrastEvidenceRefs` | design QA | วัดบนไฟล์ที่ส่งจริงทุกคู่พื้น/หมึก ที่ขนาดจริง ผ่าน 3:1 สำหรับ recognition |
| `deletionTestEvidenceRef` | ทีมผลิตภัณฑ์ | ลบมาร์กออกจากตัวบอกสถานะ ถ้าความเข้าใจไม่ลดลง กติกาบอกให้ลบ |
| `liveUsageAllowed` | หลังทุกช่องข้างบนปิด | ตอนนี้ `false` |

ระหว่างที่ยังไม่ปิด ใช้ได้เฉพาะ preview ภายในและติดป้ายว่ายังไม่อนุมัติ · ห้ามขึ้น production
พร้อมหมายเหตุว่ารออนุมัติ · hash ในตารางด้านบนผูกกับไบต์ของไฟล์ในโฟลเดอร์นี้ ถ้าแก้ไฟล์ต้องออก revision ใหม่
